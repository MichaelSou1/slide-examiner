# R5 G7 prevalence (local artifact mirror)

Date: 2026-06-25

## AutoPresent slice

- Input: `data/part3/g7_autopresent/`
- Generation summary: `reports/part3/g7_autopresent_generation.json`
- Prevalence output: `reports/part3/g7_autopresent_prevalence.jsonl`
- Result: 14/20 decks generated; 8/14 generated decks had at least one G7 hit.
- Box-level incidence: 20/50 legal boxes = 40.0%
- Hard G7: 4/50 legal boxes = 8.0%

## Zenodo10K slice

- Input: `$HOME/datasets/zenodo10k/pptx`
- Prevalence output: `/tmp/g7_zenodo298.jsonl`
- Result: 81/93 decks had at least one G7 hit.
- Box-level incidence: 857/3167 legal boxes = 27.1%
- Hard G7: 495/3167 legal boxes = 15.6%

## PPTAgent smoke

- Input: `data/part3/tasks/test.jsonl` task `p3_05_full_proposal_v1`
- Driver: `scripts/part3_g7_gen_pptagent.py`
- Output: `data/part3/g7_pptagent/pptagent_000_p3_05_full_proposal_v1.pptx`
- Smoke result: 1/1 deck generated; detector found 1/3 legal boxes with G7 hit (1 hard G7).

## Notes

- AutoPresent and PPTAgent both use mimo-compatible OpenAI endpoints.
- PPTAgent smoke used `mimo-v2.5-pro` for text and `mimo-v2.5` for vision.
